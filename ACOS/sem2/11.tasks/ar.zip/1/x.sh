#!/bin/bash

if [ "$1" == "" ]
then
	echo "lost argument 1"
	exit
fi


gcc $1 -o file -lfuse3
export LD_LIBRARY_PATH=/usr/local/lib/x86_64-linux-gnu
./file work --src dir:dir2:dir3
ls work
cd work
ls -la 
echo -e "\n"
tree
echo -e "\n"
ls * -la 
echo -e "\n"
wc */*
echo -e "\n"
cd ..
fusermount3 -u work
